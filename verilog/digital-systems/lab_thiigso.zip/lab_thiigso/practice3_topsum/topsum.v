module topsum (SW, LEDR);

input [9:0] SW;
output [9:0] LEDR;

//variaveis intermediarias

wire [1:0] A,B,Cin,Cout,S;

assign A[1:0] = SW[9:8];

assign B[1:0] = SW[1:0];

//sum1bit (A, B, Cin, S, Cout)

sum1bit FIRST  ( A[0], B[0],   0    , S[0], Cout[0]);
sum1bit SECOND ( A[1], B[1], Cout[0], S[1], Cout[1]);

assign LEDR [2:0] = {Cout[1], S[1:0]};

endmodule