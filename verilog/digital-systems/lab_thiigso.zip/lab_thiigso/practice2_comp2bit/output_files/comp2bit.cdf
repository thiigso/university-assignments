/* Quartus Prime Version 24.1std.0 Build 1077 03/04/2025 SC Lite Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(10M50DAF484) Path("C:/Users/thiag/Desktop/c_code/git/university-assingments/verilog/digital-systems/lab_thiigso/practice2_comp2bit/output_files/") File("comp2bit.sof") MfrSpec(OpMask(1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
