module comp2bit (A, B, maior, igual, menor);
input [1:0] A,B;

assign maior= (A[1] & ~B[1]) | (A[1] ~^ B[1]) & (A[0] & ~B[0]);
assign igual= (A[1] ~^ B[1]) & (A[0] ~^ B[0]);
assign menor= (~A[1] & B[1]) | (A[1] ~^ B[1]) & (~A[0] & B[0]);

output maior, igual, menor;

endmodule
